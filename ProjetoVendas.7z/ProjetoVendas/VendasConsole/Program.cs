﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendasConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Cliente> clientes = new List<Cliente>();
            int opcao;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine(" -- PROJETO DE VENDAS -- \n");
                Console.ResetColor();
                Console.WriteLine("1 - Cadastrar cliente");
                Console.WriteLine("2 - Listar clientes");
                Console.WriteLine("0 - Sair");
                Console.WriteLine("\nDigite a opção desejada:");
                opcao = Convert.ToInt32(Console.ReadLine());
                switch (opcao)
                {
                    case 1:
                        Cliente c = new Cliente();

                        Console.Clear();
                        Console.WriteLine(" -- CADASTRAR CLIENTE -- \n");
                        Console.WriteLine("Digite o nome do cliente:");
                        c.Nome = Console.ReadLine();
                        Console.WriteLine("Digite o CPF do cliente:");
                        c.Cpf = Console.ReadLine();

                        Console.WriteLine("Cliente cadastrado com sucesso!");
                        break;
                    case 2:
                        Console.Clear();
                        Console.WriteLine(" -- LISTAR CLIENTES -- \n");
                        break;
                    case 0:
                        Console.Clear();
                        Console.WriteLine("Saindo...");
                        break;
                    default:
                        Console.Clear();
                        Console.WriteLine("Opção inválida!");
                        break;
                }
                Console.WriteLine("\nAperter uma tecla para continuar...");
                Console.ReadKey();
            } while (opcao != 0);

        }
    }
}
