﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasConsole.Models;

namespace VendasConsole.DAL
{
    class Dados
    {

        public static void Inicializar()
        {
            Cliente c = new Cliente
            {
                Nome = "Lu Ribas",
                Cpf = "07936744924",
                CriadoEm = DateTime.Now,
            };

            Produto p = new Produto
            {
                Nome = "Caldo de Cana",
                Preco = 4.50,
                Quant = 20,
                CriadoEm = DateTime.Now,

            };

            Produto p2 = new Produto
            {
                Nome = "Pastel",
                Preco = 4,
                Quant = 15,
                CriadoEm = DateTime.Now,

            };

            Vendedor v = new Vendedor
            {
                Nome = "Ester Mariana",
                Cpf = "96325874123",
                CriadoEm = DateTime.Now,
            };

            ClienteDAO.CadastrarCliente(c);
            ProdutoDAO.CadastrarProduto(p);
            ProdutoDAO.CadastrarProduto(p2);
            VendedorDAO.CadastrarVendedor(v);

        }

    }
}
