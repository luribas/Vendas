﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasConsole.DAL;
using VendasConsole.Models;

namespace VendasConsole.Views
{
    class ListarVendedores
    {
        public static void Renderizar()
        {
            Console.Clear();
            Console.WriteLine(" -- LISTAR VENDEDORES -- \n");
            foreach (Vendedor clienteCadastrado in VendedorDAO.ListarVendedores())
            {
                Console.WriteLine(clienteCadastrado);
            }
        }
    }
}
