﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasConsole.DAL;
using VendasConsole.Models;

namespace VendasConsole.Views
{
    class CadastrarVenda
    {

        public static void Renderizar()
        {
            Venda venda = new Venda();
            Cliente c = new Cliente();

            Console.Clear();
            Console.WriteLine("Cadastrar Cliente da Operação");
            Console.WriteLine("Digite o CPF do cliente");
            c.Cpf = Console.ReadLine();
            c = ClienteDAO.BuscarClientePorCpf(c);
            if (c != null)
            {

            }
            


        }
    }
}
