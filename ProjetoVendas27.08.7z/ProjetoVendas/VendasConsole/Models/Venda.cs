﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendasConsole.Models
{
    class Venda
    {
        public Venda()
        {
            CriadoEm = DateTime.Now;
            Cliente = new Cliente();
            Vendedor = new Vendedor();
            Produto = new Produto();

        }

        // Relacionamento - agregação (cada parte - cliente, vendedor e produto - exite sem o todo - venda)
        public Cliente Cliente { get; set; }
        public Vendedor Vendedor { get; set; }
        public Produto Produto { get; set; }
        public int Quantidade { get; set; }
        public DateTime CriadoEm { get; set; }

        

    }
}
//Ao selecionar a sétima opção, o sistema deve realizar as seguintes
//operações:
//- Ler o CPF do cliente e verificar se o mesmo se encontra cadastrado;
//- Ler o CPF do vendedor e verificar se o mesmo se encontra cadastrado;
//- Ler o nome do produto e verificar se o mesmo se encontra cadastrado;
//- Ler a quantidade de itens que vão ser levados daquele produto;
//- Não permitir a adição deste produto, caso não tenha em estoque;
//- Registrar quantos produtos forem necessários;
//- Registrar a data da venda;
//- Criar um objeto com os dados e armazenar em uma lista;