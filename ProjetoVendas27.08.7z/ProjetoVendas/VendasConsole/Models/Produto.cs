﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendasConsole.Models
{
    public class Produto
    {
        public Produto(String nome, Double preco, int quant)
        {
            CriadoEm = DateTime.Now;
        }

        public Produto()
        {
            CriadoEm = DateTime.Now;
        }

        public string Nome { get; set; }
        public Double Preco { get; set; }
        public int Quant { get; set; }
        public DateTime CriadoEm { get; set; }

        public override string ToString()
        {
            return "Nome: " + Nome + " | Preço: " + Preco + "  | Quantidade em estoque: " + Quant;

        }

        public override bool Equals(object obj)
        {
            Produto produto = (Produto)obj;
            if (produto.Nome.Equals(Nome) && produto.Preco.Equals(Preco))
            {
                return true;
            }
            return false;
        }
    }


}